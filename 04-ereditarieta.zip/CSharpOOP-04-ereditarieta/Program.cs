﻿using CSharpOOP;

// 04-01 INTRODUZIONE
// L'ereditarietà consente di creare nuove classi che riutilizzano,
// estendono e modificano il comportamento definito in altre classi

// La classe i cui membri vengono ereditati è denominata classe di base
// mentre la classe che eredita tali membri è denominata classe derivata.

// Una classe derivata può avere una sola classe di base diretta.
// L'ereditarietà, tuttavia, è transitiva (casa => casa di legno => casa di legno in montagna)
// classe
// Cestista.cs
Cestista lebron = new Cestista() { Nome = "Lebron", Cognome = "James", DataNascita = new DateTime(1984, 12, 30) };

Console.WriteLine(lebron.NomeCompleto);
Console.WriteLine(lebron.Saluta("Ciao"));

// 04-02 SPECIALIZZAZIONE 1
// proprietà specifiche
lebron.Squadra = "L.A. Lakers";
lebron.Numero = 6;
Console.WriteLine(lebron.Squadra + " " + lebron.Numero);

// funzione specifica
lebron.ValoreSchiacciata = 90;
Console.WriteLine(lebron.Schiaccia() ? "Successo" : "Fallimento");

// costruttore specifico
var durant = new Cestista("Kevin", "Durant", new DateTime(1988, 9, 29), "Brooklyn Nets", 7);
Console.WriteLine(durant.Squadra);

// 04-03 SPECIALIZZAZIONE 2
var nicola = new Spettatore("Nicola", "Amaranti", new DateTime(2019, 9, 29), "B45");
Console.WriteLine(nicola.NumeroPostoASedere);

var kerr = new Allenatore("Steve", "Kerr", new DateTime(1965, 9, 27), "Golden State Warriors");
Console.WriteLine(kerr.Squadra);

// 04-04 EREDITARIETA TRANSITIVA
// Abbonato.cs
var alessia = new Abbonato("Alessia", "Marrone", new DateTime(1998, 2, 3), "A23", "XYZ000XYZ");
Console.WriteLine(alessia.Saluta("Buongiorno"));
Console.WriteLine($"Abbonamento: {alessia.CodiceAbbonamento}, Posto: {alessia.NumeroPostoASedere}");

// 04-05 CLASSI PARZIALI    
// è possibile seprare il codice di definizione di una classe
// in files diversi
// utile per files autogenerati (EF)
// AllenatoreStatistiche.cs
kerr.PartiteVinte = 12;
kerr.PartitePareggiate = 1;
kerr.PartitePerse = 0;
Console.WriteLine(kerr.PartiteVinte);

// 04-06 CREARE ECCEZIONI CUSTOM
// possiamo chiaramente ereditare anche dalle classi del framework
// MinorenneException.cs
try
{
    if (nicola.Anni < 18)
        throw new MinorenneException();
}
catch (MinorenneException ex)
{
    Console.WriteLine(ex.GetType());
    Console.WriteLine(ex.Message);
}
catch (Exception ex)
{
    Console.WriteLine(ex.GetType());
    Console.WriteLine(ex.Message);
}



