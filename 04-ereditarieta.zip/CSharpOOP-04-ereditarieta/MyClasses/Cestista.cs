// 04-01 INTRODUZIONE
namespace CSharpOOP
{
    public class Cestista : Persona
    {
        // Concettualmente, una classe derivata rappresenta una specializzazione della classe di base.        
        // La classe derivata acquista implicitamente tutti i membri della classe di base
        // con l'eccezione dei costruttori

        public Cestista()
        {
            Console.WriteLine("Cestista creato");
        }

        // 04-02 SPECIALIZZAZIONE 1
        public string Squadra { get; set; } = string.Empty;

        public int Numero { get; set; }

        public int ValoreSchiacciata { get; set; }

        public bool Schiaccia()
        {
            return new Random().Next(100) <= ValoreSchiacciata;
        }

        public Cestista(string nome, string cognome, DateTime dataNascita, string squadra, int numero)
            : base(nome, cognome, dataNascita)
        {
            this.Squadra = squadra;
            this.Numero = numero;
            Console.WriteLine("Cestista creato: " + base.NomeCompleto);
        }
    }
}