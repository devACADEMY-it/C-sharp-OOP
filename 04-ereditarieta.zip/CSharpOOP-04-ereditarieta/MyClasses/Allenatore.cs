namespace CSharpOOP
{
    // public class Allenatore : Persona
    public partial class Allenatore : Persona
    {
        public Allenatore(string nome, string cognome, DateTime dataNascita, string squadra)
            : base(nome, cognome, dataNascita)
        {
            this.Squadra = squadra;

            Console.WriteLine("Allenatore creato: " + base.NomeCompleto);
        }

        public string Squadra { get; set; } = string.Empty;
    }
}