namespace DevAcademy.CMS
{
    public class Manager
    {
        // private static List<Autore> autori = new List<Autore>();
        // public static List<Autore> Autori { get => autori; }

        // private static List<Categoria> categorie = new List<Categoria>();
        // public static List<Categoria> Categorie { get => categorie; }

        // private static List<Articolo> articoli = new List<Articolo>();
        // public static List<Articolo> Articoli { get => articoli; }

        public static List<Autore> Autori { get; } = new List<Autore>();
        public static List<Categoria> Categorie { get; } = new List<Categoria>();
        public static List<Articolo> Articoli { get; } = new List<Articolo>();

        public static Autore CreaAutore(string nome, string cognome)
        {
            Autore a = new Autore(nome, cognome);
            Autori.Add(a);

            return a;
        }

        public static Categoria CreaCategoria(string titolo)
        {
            Categoria c = new Categoria(titolo);
            Categorie.Add(c);
            return c;
        }

        public static Articolo CreaArticolo(string titolo, string testo, DateTime dataPubblicazione, Categoria categoria, Autore autore)
        {
            Articolo a = new Articolo(titolo, testo, dataPubblicazione, categoria, autore);
            Articoli.Add(a);
            categoria.NumeroArticoli++;
            return a;
        }

        public static Commento CreaCommento(ICommentabile Entita, Autore autore, string testo, DateTime dataPubblicazione)
        {
            Commento c = new Commento(autore, testo, dataPubblicazione);
            Entita.Commenti.Add(c);
            return c;
        }
    }
}