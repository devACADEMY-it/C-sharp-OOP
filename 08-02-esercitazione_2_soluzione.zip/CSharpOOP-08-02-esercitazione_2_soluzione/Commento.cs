namespace DevAcademy.CMS
{
    public class Commento
    {
        public Commento()
        {

        }

        public Commento(Autore autore, string testo, DateTime dataPubblicazione)
        {
            Testo = testo;
            DataPubblicazione = dataPubblicazione;
            Autore = autore;
        }

        public string Testo { get; set; } = string.Empty;
        public DateTime DataPubblicazione { get; set; }
        public Autore? Autore { get; set; }
    }
}