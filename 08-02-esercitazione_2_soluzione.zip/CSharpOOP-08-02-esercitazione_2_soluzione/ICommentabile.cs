namespace DevAcademy.CMS
{
    public interface ICommentabile
    {
        public List<Commento> Commenti { get; set; }
    }
}