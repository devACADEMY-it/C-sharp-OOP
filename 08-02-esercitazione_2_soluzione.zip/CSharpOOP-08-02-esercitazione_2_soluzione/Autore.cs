namespace DevAcademy.CMS
{
    public class Autore : ICommentabile
    {
        public Autore()
        {

        }

        public Autore(string nome, string congome)
        {
            Nome = nome;
            Cognome = congome;
        }

        public string Nome { get; set; } = string.Empty;
        public string Cognome { get; set; } = string.Empty;
        public string NomeCompleto { get => $"{Nome} {Cognome}"; }
        public List<Commento> Commenti { get; set; } = new List<Commento>();
    }
}