namespace DevAcademy.CMS
{
    public class Articolo : ICommentabile
    {
        public Articolo()
        {

        }

        public Articolo(string titolo, string testo, DateTime dataPubblicazione, Categoria categoria, Autore autore)
        {
            Titolo = titolo;
            Testo = testo;
            DataPubblicazione = dataPubblicazione;
            Categoria = categoria;
            Autore = autore;
        }

        public string Titolo { get; set; } = string.Empty;
        public string Testo { get; set; } = string.Empty;
        public DateTime DataPubblicazione { get; set; }
        public Categoria? Categoria { get; set; }
        public Autore? Autore { get; set; }
        public List<Commento> Commenti { get; set; } = new List<Commento>();
    }
}