﻿/*
08 ESERCITAZIONE SULLE INTERFACCE
Modifichiamo il nostro software in modo da rendere
commentabili (possibilità di aggiungere commenti) articoli e autori
Lo faremo attraverso la creazione ed implemntazione di una interfaccia

- namespace DevAcademy.CMS
- Creiamo una classe "Commento"
    - Proprietà Autore
    - Proprietà Testo
    - Proprietà DataPubblicazione
- Creiamo un'interfaccia "ICommentabile"
    - Proprietà Lista Commenti (da implementare): List<Commento>
- Nelle classi Autore e Articolo implementiamo l'interfaccia ICommentabile
- Modifichiamo la classe Manager
    - Motodo statico CreaCommento che accetti come parametri un ICommentabile e i dati del commento
- Dopo averer creato le classi aggiungiamo:
    - 1 Autore (ai 2 autori già esistenti)
    - 2 commenti ad un Autore
    - 2 commenti ad un Articolo
    - Stampiamo a console tutti i commenti (testo e autore) dell'Articolo del punto precendete
*/

using DevAcademy.CMS;

var rb = Manager.CreaAutore("Roberto", "Baggio");
var ft = Manager.CreaAutore("Francesco", "Totti");

var tuts = Manager.CreaCategoria("Tutorials");
var storia = Manager.CreaCategoria("Storia");

var art1 = Manager.CreaArticolo("Il Cucchiaio", "Testo...", DateTime.Now, tuts, ft);
var art2 = Manager.CreaArticolo("Vincere da solo", "Testo...", DateTime.Now, storia, rb);

// *** NUOVO CODICE QUI ***
var pr = Manager.CreaAutore("Paolo", "Rossi");
Manager.CreaCommento(rb, pr, "Bravissimo!", DateTime.Now);
Manager.CreaCommento(rb, ft, "Il mio idolo!", DateTime.Now);
Manager.CreaCommento(art1, rb, "Tecnica sopraffina", DateTime.Now);
Manager.CreaCommento(art1, pr, "Non abusare", DateTime.Now);

Console.WriteLine($"Commenti a: {art1.Titolo}");
foreach (var c in art1.Commenti)
{
    Console.WriteLine($"{c.Testo} - di {c.Autore?.NomeCompleto}");
}