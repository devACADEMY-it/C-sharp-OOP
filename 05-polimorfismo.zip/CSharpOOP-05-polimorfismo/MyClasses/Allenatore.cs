namespace CSharpOOP
{
    public partial class Allenatore : Persona
    {
        public Allenatore(string nome, string cognome, DateTime dataNascita, string squadra)
            : base(nome, cognome, dataNascita)
        {
            this.Squadra = squadra;

            Console.WriteLine("Allenatore creato: " + base.NomeCompleto);
        }

        public string Squadra { get; set; } = string.Empty;

        // 05-03 OVERRIDE
        public override string Saluta(string TipoSaluto)
        {
            return $"{base.Saluta(TipoSaluto)}\nAlleno i {Squadra}";
        }
    }
}