namespace CSharpOOP.Animali
{
    public class Cane : Animale
    {
        public override void EmettiSuono()
        {
            Console.WriteLine("Bau");
        }
    }
}