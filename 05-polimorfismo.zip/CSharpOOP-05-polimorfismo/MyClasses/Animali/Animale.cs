namespace CSharpOOP.Animali
{
    public abstract class Animale
    {
        public abstract void EmettiSuono();

        public void Dormi()
        {
            Console.WriteLine("Zzz");
        }
    }
}