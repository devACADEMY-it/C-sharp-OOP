namespace CSharpOOP
{
    public class Persona
    {
        public Persona()
        {

        }

        public Persona(string nome, string cognome, DateTime dataNascita)
        {
            this.Nome = nome;
            this.Cognome = cognome;
            this.DataNascita = dataNascita;
        }

        public string Nome = string.Empty;
        public string Cognome = string.Empty;
        public int Altezza { get; set; }
        public int Peso { get; set; }
        public string Soprannome { get; set; } = string.Empty;
        public int Id { get; private set; }
        public string Pianeta { get; } = "Terra";
        public Indirizzo? Indirizzo { get; set; }
        public string IndirizzoPerBusta
        {
            get
            {
                // return $"{NomeCompleto}\n{Indirizzo?.IndirizzoCompleto}";
                var i = Indirizzo?.IndirizzoCompleto ?? "*** INDIRIZZO MANCANTE ***";
                return $"{NomeCompleto}\n{i}";
            }
        }
        private DateTime? dataNascita;
        public DateTime DataNascita
        {
            get => dataNascita ?? DateTime.Now; // se dataNascita non è nullo tornalo, altrimenti torna DateTime.Now
            set
            {
                if (value > DateTime.Now)
                    throw new ArgumentException("Non è ancora nato");
                dataNascita = value;
            }
        }
        public string NomeCompleto { get => $"{this.Nome} {Cognome}"; }
        public int Anni { get => (int)Math.Floor(DateTime.Now.Subtract(DataNascita).TotalDays / 365); }

        // virtual: il membro può essere sovrascritto
        public virtual string Saluta(string tipoSaluto)
        {
            return $"{tipoSaluto}, sono {NomeCompleto} e ho {Anni} anni.";
        }

        public string Saluta(string tipoSaluto, string punteggiatura)
        {
            return $"{tipoSaluto}, sono {NomeCompleto} e ho {Anni} anni{punteggiatura}";
        }

        public static string Specie { get; } = "Mammifero";

        public static string CosaSono()
        {
            return $"Sono un {Specie}";
        }
    }
}