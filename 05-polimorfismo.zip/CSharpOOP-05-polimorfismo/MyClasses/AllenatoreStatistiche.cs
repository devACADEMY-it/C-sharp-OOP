namespace CSharpOOP
{
    public partial class Allenatore : Persona
    {
        public int PartiteVinte { get; set; }
        public int PartitePerse { get; set; }
        public int PartitePareggiate { get; set; }
    }
}