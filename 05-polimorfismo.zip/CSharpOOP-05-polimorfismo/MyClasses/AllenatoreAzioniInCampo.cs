namespace CSharpOOP
{
    public partial class Allenatore : Persona
    {
        // 05-02 CLASSI COME PARAMETRI DI FUNZIONE
        public string Rimprovera(Persona persona)
        {
            // step 1
            // return $"{persona.NomeCompleto}, fai più attenzione!";

            // step 2
            if (persona.GetType() == typeof(Cestista))
            {
                return $"{persona.NomeCompleto}, non giocare da solo!";
            }
            else
            {
                return $"{persona.NomeCompleto}, fai più attenzione!";
            }

        }
    }
}