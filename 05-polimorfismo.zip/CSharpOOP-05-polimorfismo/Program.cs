﻿using CSharpOOP;
using CSharpOOP.Animali;

// 05-01 INTRODUZIONE
// polimorfismo significa "molte forme"
// La classe derivata è ANCHE la classe base: Un Cestista è ANCHE una Persona
Cestista lebron = new Cestista("Lebron", "James", new DateTime(1984, 12, 30), "L.A. Lakers", 6);
Console.WriteLine(lebron.Saluta("Ciao"));
Console.WriteLine($"{lebron.NomeCompleto} tipo: {lebron.GetType()}");
Console.WriteLine($"{lebron.NomeCompleto} è Cestista: {lebron is Cestista}");
Console.WriteLine($"{lebron.NomeCompleto} è Persona: {lebron is Persona}");

Abbonato alessia = new Abbonato("Alessia", "Marrone", new DateTime(1998, 2, 3), "A23", "XYZ000XYZ");
Console.WriteLine($"{alessia.NomeCompleto} tipo: {alessia.GetType()}");
Console.WriteLine($"{alessia.NomeCompleto} è Abbonato: {alessia is Abbonato}");
Console.WriteLine($"{alessia.NomeCompleto} è Spettatore: {alessia is Spettatore}");
Console.WriteLine($"{alessia.NomeCompleto} è Persona: {lebron is Persona}");
Console.WriteLine($"{alessia.NomeCompleto} è Cestista: {alessia is Cestista}");

// 05-02 CLASSI COME PARAMETRI DI FUNZIONE
// funzione che accetta Persona accetta anche Cestista
// AllenatoreAzioniInCampo.cs
var kerr = new Allenatore("Steve", "Kerr", new DateTime(1965, 9, 27), "Golden State Warriors");
Console.WriteLine(kerr.Rimprovera(lebron));

var nicola = new Spettatore("Nicola", "Amaranti", new DateTime(2019, 9, 29), "B45");
Console.WriteLine(kerr.Rimprovera(nicola));

var mario = new Persona("Mario", "Rossi", new DateTime(2019, 4, 6));
Console.WriteLine(kerr.Rimprovera(mario));


// 05-03 OVERRIDE
// sovrascriviamo un membro della classe
// settiamo Persona.Saluta(string TipoSaluto) come virtual

// override di Cestista
Console.WriteLine(lebron.Saluta("Ciao"));

// override di Allenatore
Console.WriteLine(kerr.Saluta("Ciao"));

Console.WriteLine(mario.Saluta("Ciao"));
Console.WriteLine(nicola.Saluta("Ciao"));

// 05-04 CLASSI ASTRATTE
// classi che non possono essere istanziate direttamente
// me che DEVONO essere derivate
// Animale.cs
// Cane.cs, Gatto.cs

// var animale = new Animale(); // errore
var gatto = new Gatto();
var cane = new Cane();

gatto.EmettiSuono();
gatto.Dormi();
cane.EmettiSuono();
cane.Dormi();
