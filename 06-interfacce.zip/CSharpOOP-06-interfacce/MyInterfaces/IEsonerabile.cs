
namespace CSharpOOP
{
    // 06-02 INTERFACCE MULTIPLE
    public interface IEsonerabile
    {
        void Esonerami(DateTime dataEsonero);
        DateTime? DataUltimoEsonero { get; }
    }
}