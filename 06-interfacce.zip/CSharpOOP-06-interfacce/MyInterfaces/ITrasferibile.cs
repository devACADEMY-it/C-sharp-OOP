namespace CSharpOOP
{
    public interface ITrasferibile
    {
        public void TrasferiscimiA(string nuovaSquadra);
    }
}