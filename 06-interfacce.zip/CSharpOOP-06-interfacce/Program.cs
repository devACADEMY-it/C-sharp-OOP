﻿using CSharpOOP;

// 06-01 DEFINIZIONE E IMPLEMENTAZIONE
// Un'interfaccia definisce un contratto
// Qualsiasi classe che implementa tale contratto
// deve fornire un'implementazione dei membri definiti nell'interfaccia
// ITrasferibile.cs
var lebron = new Cestista("Lebron", "James", new DateTime(1984, 12, 30), "L.A. Lakers", 6);
var alessia = new Abbonato("Alessia", "Marrone", new DateTime(1998, 2, 3), "A23", "XYZ000XYZ");
var kerr = new Allenatore("Steve", "Kerr", new DateTime(1965, 9, 27), "Golden State Warriors");

// posso trasferire solo le classi che implementano ITrasferibile
// a prescindere dalla classe
void Trasferisci(ITrasferibile persona, string nuovaSquadra)
{
    persona.TrasferiscimiA(nuovaSquadra);
}

Console.WriteLine(lebron.Saluta("Addio"));
Trasferisci(lebron, "Chicago Bulls");
Console.WriteLine(lebron.Saluta("Salve"));

Console.WriteLine(kerr.Saluta("Addio"));
Trasferisci(kerr, "Boston Celtics");
Console.WriteLine(kerr.Saluta("Salve"));

// Trasferisci(alessia, "Boston Celtics"); // ERRORE

// 06-02 INTERFACCE MULTIPLE
// una classe può ereditare SOLO da UN'altra classe
// una classe può implementare n interfacce
// IEsonerabile.cs
void Esonera(IEsonerabile persona, DateTime dataEsonero)
{
    persona.Esonerami(dataEsonero);
}

Console.WriteLine("Data ultimo esonero: " + kerr.DataUltimoEsonero);
Console.WriteLine("Squadra: " + kerr.Squadra);
Esonera(kerr, DateTime.Now);
Console.WriteLine("Data ultimo esonero: " + kerr.DataUltimoEsonero);
Console.WriteLine("Squadra: " + kerr.Squadra);
// Esonera(lebron, DateTime.Now); // ERRORE

// 06-03 INTERFACCE DEL FRAMEWORK
// Abbonato.cs
var nicola = new Abbonato("Alessia", "Marrone", new DateTime(1998, 2, 3), "B45", "YYY000XXX");
Console.WriteLine("nicola == alessia: " + nicola.Equals(alessia));

// IEnumerable
void StampaLaLista(IEnumerable<string> lista)
{
    foreach (var item in lista)
    {
        Console.WriteLine(item);
    }
}

List<string> l = new List<string>() { "ciao", "come", "stai" };
string[] a = new string[] { "molto", "bene", "grazie" };

StampaLaLista(l);
StampaLaLista(a);