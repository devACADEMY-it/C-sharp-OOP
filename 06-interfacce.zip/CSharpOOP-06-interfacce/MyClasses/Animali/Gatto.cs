namespace CSharpOOP.Animali
{
    public class Gatto : Animale
    {
        public override void EmettiSuono()
        {
            Console.WriteLine("Miao");
        }
    }
}