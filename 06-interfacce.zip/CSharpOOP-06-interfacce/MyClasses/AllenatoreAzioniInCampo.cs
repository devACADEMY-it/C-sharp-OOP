namespace CSharpOOP
{
    public partial class Allenatore : Persona
    {
        public string Rimprovera(Persona persona)
        {
            if (persona.GetType() == typeof(Cestista))
            {
                return $"{persona.NomeCompleto}, non giocare da solo!";
            }
            else
            {
                return $"{persona.NomeCompleto}, fai più attenzione!";
            }

        }
    }
}