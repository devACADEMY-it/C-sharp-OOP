namespace CSharpOOP
{
    // 06-01 INTRODUZIONE
    public class Cestista : Persona, ITrasferibile
    {
        public Cestista()
        {
            Console.WriteLine("Cestista creato");
        }

        public string Squadra { get; set; } = string.Empty;

        public int Numero { get; set; }

        public int ValoreSchiacciata { get; set; }

        public bool Schiaccia()
        {
            return new Random().Next(100) <= ValoreSchiacciata;
        }

        public Cestista(string nome, string cognome, DateTime dataNascita, string squadra, int numero)
            : base(nome, cognome, dataNascita)
        {
            Squadra = squadra;
            Numero = numero;
        }

        public override string Saluta(string tipoSaluto)
        {
            return $"{tipoSaluto}, sono {NomeCompleto} e ho {Anni} anni.\nGioco nei {Squadra} col numero {Numero}";
        }

        public void TrasferiscimiA(string nuovaSquadra)
        {
            Squadra = nuovaSquadra;
        }
    }
}