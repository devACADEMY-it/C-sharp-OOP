namespace CSharpOOP
{
    // 06-01 INTRODUZIONE
    public partial class Allenatore : Persona, ITrasferibile, IEsonerabile
    {
        public Allenatore(string nome, string cognome, DateTime dataNascita, string squadra)
            : base(nome, cognome, dataNascita)
        {
            this.Squadra = squadra;
        }

        public string Squadra { get; set; } = string.Empty;

        public override string Saluta(string TipoSaluto)
        {
            return $"{base.Saluta(TipoSaluto)}\nAlleno i {Squadra}";
        }

        public void TrasferiscimiA(string nuovaSquadra)
        {
            Squadra = nuovaSquadra;
        }

        // 06-02 INTERFACCE MULTIPLE
        public void Esonerami(DateTime dataEsonero)
        {
            Squadra = "NESSUNA";
            dataUltimoEsonero = dataEsonero;
        }

        private DateTime? dataUltimoEsonero;
        public DateTime? DataUltimoEsonero
        {
            get => dataUltimoEsonero;
        }
    }
}