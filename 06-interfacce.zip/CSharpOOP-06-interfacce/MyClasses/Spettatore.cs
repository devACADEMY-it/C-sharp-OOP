namespace CSharpOOP
{
    public class Spettatore : Persona
    {
        public Spettatore(string nome, string cognome, DateTime dataNascita, string numeroPostoASedere)
            : base(nome, cognome, dataNascita)
        {
            this.NumeroPostoASedere = numeroPostoASedere;
        }

        public string NumeroPostoASedere { get; set; } = string.Empty;
    }
}