namespace CSharpOOP
{
    // 06-03 INTERFACCE DEL FRAMEWORK
    public class Abbonato : Spettatore, IEquatable<Abbonato>
    {
        public Abbonato(string nome, string cognome, DateTime dataNascita, string numeroPostoASedere, string codiceAbbonamento)
            : base(nome, cognome, dataNascita, numeroPostoASedere)
        {
            CodiceAbbonamento = codiceAbbonamento;
        }

        public string CodiceAbbonamento { get; set; }

        public bool Equals(Abbonato? other)
        {
            return Nome == other?.Nome && Cognome == other?.Cognome && DataNascita == other?.DataNascita;
        }
    }
}