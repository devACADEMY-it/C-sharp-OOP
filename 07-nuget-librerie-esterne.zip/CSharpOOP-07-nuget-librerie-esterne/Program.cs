﻿// 07-01 INSTALLAZIONE LIBRERIA
// installazione libreria CsvHelper
// dotnet add package CsvHelper
// controlliamo il file di progetto
// oppure dotnet list package
// la libreria (assembly) contiene classi e altro
using CsvHelper;
using System.Globalization;

// 07-02 LETTURA FILE CSV
// Persona.cs
using var reader = new StreamReader("persone.csv");
using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
var persone = csv.GetRecords<Persona>().ToList();

Console.WriteLine("Persone totali: " + persone.Count);

// 07-03 ATTRIBUTI
// metadati che applichiamo ai membri
// Documentazione CsvHelper
// https://joshclose.github.io/CsvHelper/examples/configuration/attributes/

void StampaPersona(Persona persona)
{
    Console.WriteLine($"{persona.Id.ToString().PadRight(5)}{persona.Nome.PadRight(15)}{persona.Cognome.PadRight(15)}{persona.DataNascita.Date.ToShortDateString()}");
}

foreach (var p in persone)
{
    StampaPersona(p);
}
