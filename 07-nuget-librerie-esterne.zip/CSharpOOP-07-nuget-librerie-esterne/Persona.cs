// 07-02 LETTURA FILE CSV
using CsvHelper.Configuration.Attributes;

public class Persona
{
    // public int id { get; set; }

    // public string nome { get; set; } = string.Empty;

    // public string cognome { get; set; } = string.Empty;

    // public int dataNascita { get; set; }

    // 07-03 ATTRIBUTI
    [Name("id")]
    public int Id { get; set; }

    [Name("nome")]
    public string Nome { get; set; } = string.Empty;

    [Name("cognome")]
    public string Cognome { get; set; } = string.Empty;

    [Name("dataNascita")]
    public int DataNascitaEpoch { get; set; }
    public DateTimeOffset DataNascita { get => DateTimeOffset.FromUnixTimeSeconds(DataNascitaEpoch); }
}