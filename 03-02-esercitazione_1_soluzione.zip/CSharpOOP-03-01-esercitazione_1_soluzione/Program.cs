﻿/*
03 ESERCITAZIONE SULLE CLASSI
Creiamo un CMS (Content Management System - Tipo Wordpress) che gestisca la pubblicazione di Articoli
Preoccupiamoci della suddivisione in classi delle entità che compongono il nostro progetto
- Creiamo 1 file per ogni classe
- Usiamo il namespace "DevAcademy.CMS" per ogni classe
- Classe "Autore" con i seguenti membri
    - Porprietà Nome
    - Porprietà Cognome    
- Classe "Categoria" con i seguenti membri
    - Porprietà Titolo
    - Porprietà NumeroArticoli (elenco Articoli appertenenti alla Categoria)
- Classe "Articolo" con i seguenti membri
    - Porprietà Titolo
    - Porprietà Testo
    - Porprietà DataPubblicazione
    - Porprietà Categoria (tipo di dato Classe Categoria nullable)
    - Porprietà Autore (tipo di dato Classe Autore nullable)
- Classe "Manager" con i seguenti membri (tutti statici)
    - Poprietà Lista Autori (solo get)
    - Poprietà Lista Categorie (solo get)
    - Poprietà Lista Articoli (solo get)
    - Metodo Crea Autore
    - Metodo Crea Categoria
    - Metodo Crea Articolo

    Questa classe si preoccuperà della business logic del nostro programma,
    conterrà cioè tutte le funzioni (metodi) per la gestione del CMS

    Cercate di capire in autonomia, in base alle proprietà delle classi (Autore, Categoria, Articolo di cui sopra)
    quali saranno i parametri dei metodi, e le istruzioni da eseguire
- Dopo avere creato le classi:
    - Create 2 Autori
    - Create 2 Categorie
    - Create 2 Articoli (utilizzando le Categorie e gli Autori creati in precedenza)
    - Stampare in console il totale degli Articoli presenti in ogni Categoria
    - Stampate in console gli articoli creati, visualizzando anche le info su Autore e Categoria
    - Stampare in console il totale delle Liste (Autori, Categorie, Articoli) dell'oggetto Manager
*/

using DevAcademy.CMS;

var rb = Manager.CreaAutore("Roberto", "Baggio");
var ft = Manager.CreaAutore("Francesco", "Totti");

var tuts = Manager.CreaCategoria("Tutorials");
var storia = Manager.CreaCategoria("Storia");

Manager.CreaArticolo("Il Cucchiaio", "Testo...", DateTime.Now, tuts, ft);
Manager.CreaArticolo("Vincere da solo", "Testo...", DateTime.Now, storia, rb);

Console.WriteLine("Totale articoli Tutorials: " + tuts.NumeroArticoli);
Console.WriteLine("Totale articoli Storia: " + storia.NumeroArticoli);

Console.WriteLine("*** Articoli ***");
foreach (var articolo in Manager.Articoli)
{
    Console.WriteLine(articolo.Titolo);
    Console.WriteLine($"di {articolo.Autore?.NomeCompleto}");
    Console.WriteLine($"pubblicato il {articolo.DataPubblicazione.ToShortDateString()} in {articolo.Categoria?.Titolo}");
    Console.WriteLine();
    Console.WriteLine(articolo.Testo);
    Console.WriteLine();
}

Console.WriteLine("Totale autori: " + Manager.Autori.Count);
Console.WriteLine("Totale categorie: " + Manager.Categorie.Count);
Console.WriteLine("Totale articoli: " + Manager.Articoli.Count);