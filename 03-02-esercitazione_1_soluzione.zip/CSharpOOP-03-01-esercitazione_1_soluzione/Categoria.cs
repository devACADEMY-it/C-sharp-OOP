namespace DevAcademy.CMS
{
    public class Categoria
    {
        public Categoria()
        {

        }

        public Categoria(string titolo)
        {
            Titolo = titolo;
            NumeroArticoli = 0;
        }

        public string Titolo { get; set; } = string.Empty;
        public int NumeroArticoli { get; set; }
    }
}