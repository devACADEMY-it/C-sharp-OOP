﻿// 02-01 INCAPSULAMENTO E ACCESSIBILITÀ
// Persona.cs

using CSharpOOP;

var mario = new Persona();

// 02-02 PROPRIETA
mario.Nome = "Mario";
mario.Cognome = "Rossi";
// p.DataNascita = new DateTime(2987, 2, 4);
mario.DataNascita = new DateTime(1987, 2, 4);
Console.WriteLine(mario.DataNascita);

// 02-03 PROPRIETA AVANZATE
Console.WriteLine(mario.NomeCompleto);
Console.WriteLine(mario.Anni);


// 02-04 METODI
var paola = new Persona()
{
    Nome = "Paola",
    Cognome = "Verdi",
    DataNascita = new DateTime(2000, 3, 7)
};

Console.WriteLine(mario.Saluta("Ciao"));
Console.WriteLine(paola.Saluta("Ciao", "!!!"));

// 02-05 COSTRUTTORE
var luigi = new Persona("Luigi", "Bianchi", new DateTime(1976, 4, 6));

// 02-06 PROPRIETÀ E METODI STATICI
Console.WriteLine(DateTime.Now);
Console.WriteLine(Persona.Specie);

// 02-07 CLASSI COME MEMBRI
var giulia = new Persona("Giulia", "Gialli", new DateTime(2001, 1, 1));
var indirizzo = new Indirizzo()
{
    Via = "Via della Libertà",
    Civico = "456",
    CAP = "80079",
    Citta = "Procida",
    Provincia = "NA",
    Stato = "Italia"
};
giulia.Indirizzo = indirizzo;
Console.WriteLine(giulia.Indirizzo.Citta);
Console.WriteLine(giulia.IndirizzoPerBusta);
Console.WriteLine(mario.IndirizzoPerBusta);


