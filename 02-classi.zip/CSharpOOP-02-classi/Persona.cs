// 02-01 INCAPSULAMENTO E ACCESSIBILITÀ
// OOP incapsulamento: nascondere lo stato interno e le funzionalità di un oggetto
//                     e consentire l'accesso solo tramite un set pubblico di funzioni.

// assembly: unità fondamentali di pubblicazione e riuso nelle applicazioni .NET
//           possono assumere forma di files: .exe o .dll

// implementiamo l'incapsulamento attraverso
// il livello di accessibilità della classe e dei suoi membri
// public               accesso consentito a tutti
// protected            accesso limitato alla classe che lo contiene o ai tipi che derivano dalla classe che lo contiene
// internal             accesso limitato all'assemply (~ libreria) corrente
// protected internal	accesso limitato all'assembly (~ libreria) corrente o ai tipi che derivano dalla classe che lo contiene
// private              accesso limitato alla classe che lo contiene
// private protected	accesso limitato alla classe che lo contiene o ai tipi che derivano dalla classe che lo contiene all'interno all'assemply (~ libreria) corrente
// https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/access-modifiers

namespace CSharpOOP
{
    public class Animale
    {
        // membri (proprietà e metodi)
    }

    internal class Persona
    {
        // 02-02 PROPRIETA
        /// campo
        // public string Nome = string.Empty;

        private string nome = string.Empty;
        public string Nome
        {
            get
            {
                return nome;
            }
            set
            {
                nome = value;
            }
        }

        // proprietà full
        private string cognome = string.Empty; // incapsulamento
        public string Cognome
        {
            get { return cognome; }
            set { cognome = value; }
        }

        // proprietà full
        private int altezza;
        public int Altezza
        {
            get => altezza;
            set => altezza = value;
        }

        // proprietà breve
        public int Peso { get; set; }

        // 02-03 PROPRIETA AVANZATE
        // proprietà breve con valore di default
        public string Soprannome { get; set; } = string.Empty;

        // read only
        public int Id { get; private set; }

        public string Pianeta { get; } = "Terra";

        // validazione
        private DateTime? dataNascita;
        public DateTime DataNascita
        {
            get => dataNascita ?? DateTime.Now; // se dataNascita non è nullo tornalo, altrimenti torna DateTime.Now
            set
            {
                if (value > DateTime.Now)
                    throw new ArgumentException("Non è ancora nato");
                dataNascita = value;
            }
        }

        // calcolate
        public string NomeCompleto { get => $"{this.Nome} {Cognome}"; }
        public int Anni { get => (int)Math.Floor(DateTime.Now.Subtract(DataNascita).TotalDays / 365); }

        // 02-04 METODI E OVERLOAD
        // sono funzioni. vale tutto quello che abbiamo già detto nel corso C# Funzioni
        public string Saluta(string tipoSaluto)
        {
            return $"{tipoSaluto}, sono {NomeCompleto} e ho {Anni} anni.";
        }

        // overload
        public string Saluta(string tipoSaluto, string punteggiatura)
        {
            return $"{tipoSaluto}, sono {NomeCompleto} e ho {Anni} anni{punteggiatura}";
        }

        // 02-05 COSTRUTTORE
        // metodo che viene invocato nel momento in cui la classe viene istanziata
        // utile anche per valorizzare proprietà in fase di creazione
        public Persona()
        {
            Console.WriteLine("Oggetto creato");
        }

        public Persona(string nome, string cognome, DateTime dataNascita)
        {
            this.Nome = nome;
            this.Cognome = cognome;
            this.DataNascita = dataNascita;
            Console.WriteLine("Oggetto creato con parametri");
        }

        // 02-06 PROPRIETÀ E METODI STATICI
        // metodi e proprietà che possono essere chiamati dalla classe
        // anche quando la classe non è stata istanziata
        // NON cambiano in base all'istanza        
        public static string Specie { get; } = "Mammifero";

        public static string CosaSono()
        {
            return $"Sono un {Specie}";

            // non ho accesso a this e quindi neanche a tutti i membri non statici
            // return $"Vivo sull {this.Pianeta}";
        }

        // 02-07 CLASSI COME MEMBRI
        // classe Indirizzo.cs
        // nello stesso modo in cui utilizziamo classi del framewrok (string, DateTime, ecc)
        // possiamo utilizzare le nostre
        // qualsiasi cosa è una classe
        public Indirizzo? Indirizzo { get; set; }

        public string IndirizzoPerBusta
        {
            get
            {
                // return $"{NomeCompleto}\n{Indirizzo?.IndirizzoCompleto}";
                var i = Indirizzo?.IndirizzoCompleto ?? "*** INDIRIZZO MANCANTE ***";
                return $"{NomeCompleto}\n{i}";
            }
        }
    }
}