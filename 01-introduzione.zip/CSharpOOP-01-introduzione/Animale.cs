namespace CSharpOOP.Models
{
    public class Animale
    {

    }
}
