﻿// 01-02 CREAZIONE E ANALISI PROGETTO
// dotnet new console -o CSharpOOP

// See https://aka.ms/new-console-template for more information
// Console.WriteLine("Hello, World!");

using CSharpOOP.Models;

namespace CSharpOOP // namespace
{
    internal class Program // classe
    {
        static void Main(string[] args)
        {
            // oggetto
            Console.WriteLine("Hello World!");

            // 01-03 CLASSI
            // è il progetto per la creazione di oggetti di questo tipo
            // vedi file Persona.cs

            // 01-04 OGGETTI E ISTANZE
            // un oggetto è un'entità reale che si basa su una classe
            // un oggetto viene SEMPRE creato da una classe

            // spesso ci si riferisce ad un oggetto come ad una istanza di una classe
            // cioè a quell'oggetto specifico che è stato istanziato da una classe

            // articolo indeterminativo UNA Persona (classe)
            // articolo determinativo LA Persona che si chiama Gigi (oggetto o istanza)

            // gli oggetti sono creati usando la parola chiave "new" seguita dal nome della classe su cui si basano
            Persona p = new Persona();
            Persona p2 = new Persona();

            // 01-05 NAMESPACE
            // servono per organizzare le classi
            Models.Animale a = new Models.Animale();
            System.Console.WriteLine("test");

            // using
            Animale a2 = new Animale();

            // creiamo cartella Models e spostiamo Persona.cs e Animale.cs
            // aggiungiamo namespace a Persona.cs
            // !!! Models.Persona p2 = new Models.Persona();

            // net6
            // Implicit using directives
            // test: commenta nel file del progetto: ImplicitUsings

            // using System;
            // using System.IO;
            // using System.Collections.Generic;
            // using System.Linq;
            // using System.Net.Http;
            // using System.Threading;
            // using System.Threading.Tasks;
        }
    }
}
