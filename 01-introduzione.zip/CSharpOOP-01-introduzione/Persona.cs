// progetto per la creazione dell'oggetto Persona
public class Persona
{

}